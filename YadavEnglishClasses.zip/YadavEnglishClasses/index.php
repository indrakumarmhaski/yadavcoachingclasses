<?php
    
$con=mysqli_connect('localhost','id5135699_root','Indra@123');
      mysqli_select_db($con,'id5135699_ycc');  
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Yadav English Classes</title>

  <script defer src="https://use.fontawesome.com/releases/v5.0.3/js/all.js"></script>
  <script defer src="https://use.fontawesome.com/releases/v5.0.3/js/v4-shims.js"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm"
    crossorigin="anonymous">

  <link rel="stylesheet" href="css/index_style.css">
</head>

<body>


  <div class="container-fluid">  <!-- The main container of all the elements in body -->
    <nav class="navbar navbar-expand-lg navbarstyle" >
      <!-- Start of navbar -->
      <div class=" navbar-collapse mo-num ml-lg-4 ml-xs-1 ml-sm-2">
        <a class="mobilenumber" href="">
          <i class="fa fa-phone" style="color:white;"></i>
          <span style="color:white;">
            09752963965
          </span>
        </a>
      </div>
      <div class="quik-links justify-content-end" id="navbarCollapse">
        <ul class="navbar-nav">
          <li class="box-list" class="nav-item dropdown mr-auto">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true"
              aria-expanded="false">
              Quick Links
            </a>
            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
              <a class="dropdown-item" href="">
                <i class="fas fa-phone-square"></i>
                09752963965
              </a>
              <div class="dropdown-divider"></div>
              <a class="dropdown-item" href="">
                <i class="fas fa-envelope-square"></i>
                yadavenglishclasses@gmail.com
              </a>
              <div class="dropdown-divider"></div>
              <a class="dropdown-item" href="getfeestructure.html">
                  <i class="far fa-credit-card"></i>
                Fee Structure
              </a>
            
            <div class="dropdown-divider"></div>
              <a class="dropdown-item" href="php/loginform.php">
              <i class="fas fa-user"></i>
                Login (owner only)
              </a>
            </div>
          </li>
        </ul>
      </div>
    </nav>    <!-- End of the navbar Job completed -->

    <section>      <!-- Section for the heading(yadav coching classes) of site -->
      <div class="siteheading mt-4">
        <div class="sitebranding">
          <h2 class="sitetitle">
            <span href="">Yadav Coaching Classes</span>
          </h2>
          <p class="sitedescription">Learn English as it is fun !</p>
        </div>
      </div>
    </section>    <!-- ...Heading -->

    <section class="row introduction">  <!--For site introduction section having a background imgae  -->
      <div class="introdescription">
        <h3 class="firstif">IF you are not willing to learn,
          <br> no one can help you.</h3>
        <h2 class="secondif">If you are determind to learn,
          <br> no one can stop you.</h2>
      </div>
    </section><!-- ...site intoduction with background image -->


    <section class="batch-info">      <!-- Section for betch info. just below on intro. section -->
      <div class="box-list-container">
        <!-- consist of four different boxes -->
        <ul class="box-list">
          <li class="box-list-item">
            <div class="box box-1 text-center">
              <span>
                <img src="images/for10th.png" alt="10th">
              </span>
              <h3>10th class</h3>
              <h3 class="text-bold">BATCHES</h3>
              <a href="10thclass.php" class="btn btn-outline-dark">Know more</a>
            </div>
          </li>
          <li class="box-list-item">
            <div class="box box-2 text-center">
              <span>
                <img src="images/for11th.png" alt="11th">
              </span>
              <h3>11th class </h3>
              <h3 class="text-bold">BATCHES</h3>
              <a href="11thclass.php" class="btn btn-outline-dark">Know more</a>
            </div>
          </li>
          <li class="box-list-item">
            <div class="box box-3 text-center">
              <span>
                <img src="images/for12th.png" alt="12th">
              </span>
              <h3>12th class </h3>
              <h3 class="text-bold">BATCHES</h3>
              <a href="12thclass.php" class="btn btn-outline-dark">Know more</a>
            </div>
          </li>
          <li class="box-list-item">
            <div class="box box-4 text-center">
              <span>
                <img src="images/forspokn.png" alt="spokn">
              </span>
              <h3>Spoken English </h3>
              <h3 class="text-bold">Compititive</h3>
              <a href="spokenenglish.php" class="btn btn-outline-dark">Know more</a>
            </div>
          </li>
        </ul>
      </div>      <!-- ...box container -->
    </section>
    <!-- ...box section  -->

    <hr>

    <section class="about-us">      <!-- Section for about us -->
      <h2 class="text-center" style="text-decoration:underline;">
        <i class="fas fa-users"></i>
        About Us</h2>
      <div class="container">
        <p class="text-center text-lead">
          Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy
          text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen
          book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially
          unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages,
          and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
        </p>
        <br>
      </div>
    </section>      <!-- ...About us -->

    <section class="row whytochooseusimage"></section>    <!-- Why to choose us fiexed image on large screen -->
    <hr>


    <section class="why-tochoose-us mt-5">   <!-- Why to choose us text section -->
      <h2 class="text-center" style="text-decoration:underline;">
        Why Choose us
        <i class="fas fa-question"></i>
      </h2>
      <br>
      <div class="container">        <!-- Container of all reasons -->
        <div class="row">
          <div class="col-md-4">
            <h3 class="text-center">
                <img src="images/whytochooseus1.png" alt="10th">
            </h3>
            <h4 class="text-center" style="color: #464242">Teacher</h4>
            <p class="text-center">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's
              standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to
              make a type specimen book. It has survived not only five centuries, but also the</p>
          </div>
          <div class="col-md-4">
            <h3 class="text-center">
                <img src="images/whytochooseus2.png" alt="10th">
            </h3>
            <h4 class="text-center" style="color: #464242">Affordable fee structure</h4>
            <p class="text-center">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's
              standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to
              make a type specimen book. It has survived not only five centuries, but also the</p>
          </div>
          <div class="col-md-4">
            <h1 class="text-center" style="font-size: 53px; color: #3e3b3b;">
                <i class="fas fa-graduation-cap"></i>
            </h1>
            <h4 class="text-center" style="color: #464242">You got a strong foundation  </h4>
            <p class="text-center">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's
              standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to
              make a type specimen book. It has survived not only five centuries, but also the</p>
          </div>
        </div>
      </div>      <!-- ...Reason container -->
    </section>    <!-- ...why to choose us -->

    <hr>


    <section class="row ongoing-betches">      <!-- Mostly editable section for ongoing betches -->
      <div class="col-12">
        <h1 class="text-center mt-3" style="color: white">On-Going Betches</h1>
        <br>
        <table class="table" style="color: white;">
          <thead>
            <th>S.no.</th>
            <th>Betch</th>
            <th>Time</th>
            <th>Location</th>
          </thead>
          <tbody>
          <?php
                $q="select * from betchtiming";
                $r=mysqli_query($con,$q);
                $arr2=mysqli_fetch_array($r); 
         ?>
          <tr>
                              <td>1</td>
                              <td> 
                                   <?php echo $arr2['b1'] ?>
                              </td>
                              <td> 
                                   <?php echo $arr2['t1'] ?>
                              </td>
                              <td> 
                                   <?php echo $arr2['l1'] ?>
                              </td>
                          </tr>
                          <tr>
                              <td>2</td>
                              <td> 
                                   <?php echo $arr2['b2'] ?>
                              </td>
                              <td> 
                                   <?php echo $arr2['t2'] ?>
                              </td>
                              <td> 
                                   <?php echo $arr2['l2'] ?>
                              </td>
                          </tr>
                          <tr>
                              <td>3</td>
                              <td> 
                                   <?php echo $arr2['b3'] ?>
                              </td>
                              <td> 
                                   <?php echo $arr2['t3'] ?>
                              </td>
                              <td> 
                                   <?php echo $arr2['l3'] ?>
                              </td>
                          </tr>
                          <tr>
                              <td>4</td>
                              <td> 
                                   <?php echo $arr2['b4'] ?>
                              </td>
                              <td> 
                                   <?php echo $arr2['t4'] ?>
                              </td>
                              <td> 
                                   <?php echo $arr2['l4'] ?>
                              </td>
                          </tr>
                          <tr>
                              <td>5</td>
                              <td> 
                                   <?php echo $arr2['b5'] ?>
                              </td>
                              <td> 
                                   <?php echo $arr2['t5'] ?>
                              </td>
                              <td> 
                                   <?php echo $arr2['l5'] ?>
                              </td>
                          </tr>
          </tbody>
        </table>
      </div>
    </section>    <!-- Ongoing betches -->

    <br>

    <!-- Heading how to contect us -->
    <h2 class="text-center pb-lg-4 pb-sm-2 pb-xs-2">
      <i class="far fa-address-card"></i>
      How to contect us?</h2>      <!-- ...Heading how to contect us  -->
 
 


   <section class="row contect-us">     <!-- How to contect us main contect -->
      <div class="col-md-6 col-sm-12 col-sx-12">
        <p class="text-center text-lead mt-lg-3 mt-sm-0 mt-xs-0">
          <!-- how to contect us description -->
          Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy
          text ever since the 1500s when an unknown printer took a galley of type and scrambled it to make a type specimen
          book.
        </p>
      </div>
      <article class="col-md-6 table-costome">
        <dl class="dl-horizontal">
          <dt>Email:</dt>
          <dd>yadavenglishclasses@gmail.com</dd>
          <br>
          <dt>Address</dt>
          <dd>
            <address>Krshnapura tikari, Betul, MP, INDIA </address>
          </dd>
          <br>
          <dt>Mobile</dt>
          <dd>+91 97529 63965</dd>
        </dl>
      </article>
    </section>    <!-- ...How to contect us -->

      <br>
       <hr>

    <div class="gallery-section-container">      <!-- Main container of gallery section -->
      <section class="container gallery ">      <!-- Section gallery section -->
        <h2 class="text-center pt-3 mb-lg-5 mb-s" style="color: white; ">
          <i class="fas fa-images"></i>
          Gallery</h2>
        <div class="img-container img-fluid">

          <div id="demo" class="carousel slide" data-ride="carousel">
            <ul class="carousel-indicators">
              <li data-target="#demo" data-slide-to="0" class="active"></li>
              <li data-target="#demo" data-slide-to="1"></li>
              <li data-target="#demo" data-slide-to="2"></li>
              <li data-target="#demo" data-slide-to="3"></li>
              <li data-target="#demo" data-slide-to="4"></li>
              <li data-target="#demo" data-slide-to="5"></li>
            </ul>
            <div class="carousel-inner">
              <div class="carousel-item active">
                <img src="images/img_slide1.jpg" class="img-fluid gallery-img" alt="Los Angeles">
              </div>
              <div class="carousel-item">
                <img src="images/img_slide5.jpg" class="img-fluid gallery-img" alt="Chicago">
              </div>
              <div class="carousel-item">
                <img src="images/img_slide3.jpg" class="img-fluid gallery-img" alt="New York">
              </div>
              <div class="carousel-item">
                <img src="images/img_slide4.jpg" class="img-fluid gallery-img" alt="New York">
              </div>
              <div class="carousel-item">
                <img src="images/img_slide2.jpg" class="img-fluid gallery-img" alt="New York">
              </div>
            </div>

            <a class="carousel-control-prev" href="#demo" data-slide="prev">
              <span class="carousel-control-prev-icon" style="background-color: black;"></span>
            </a>
            <a class="carousel-control-next" href="#demo" data-slide="next">
              <span class="carousel-control-next-icon" style="background-color: black;"></span>
            </a>
          </div>
        </div>
        <!-- End of img container -->
      </section>      <!-- ...Gallery section -->
    </div>    <!-- whole Gallery container -->


    <section class="site-footer">      <!-- Footer section of site -->
      <div class="container">
        <div class="row text-center">
          <div class="col-lg-7 mt-4 tex-center">
            <h5 style="color: #fff">OUR MISSION</h5>
            <p style="color:#d6d6d6;font-style: italic;">
              Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy
              text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen
              book.
            </p>
          </div>

          <article class="col-md-5 mt-lg-5 mt-sm-1 mt-xs-1 pt-lg-3 table-costome">
            <dl class="dl-horizontal">
              <dt style="color: #fff">Director: </dt>
              <dd style="color:#d6d6d6;font-style: italic;">Purushottam Yadav</dd>
              <br>
              <dt style="color: #fff">Address: </dt>
              <dd>
                <address style="color:#d6d6d6;font-style: italic;">Krshnapura tikari, Betul, MP, INDIA </address>
              </dd>
            </dl>

          </article>
        </div>
        <!-- horizontal line between ourmission and copiright section -->
        <hr style="color: white; border-top: 1px solid white; margin-top: 0;">
        <div class="text-center" style="font-size:2em;">
          <a style="color: #919394;" href="https://www.facebook.com/purushottam.yadav.16752">
          <i class="icon 3x fab fa-facebook-square"></i>
          </a>
        </div>
        <br>

        <p class="text-center copiright">&copy; Copyright
          <script>document.write(new Date().getFullYear())</script>
          <span style="color: #d6d6d6">Yadav Coaching Classes</span>
        </p>
        <!-- Devloper section -->
        <blockquote class="blockquote pb-3 text-left" style="color:#d6d6d6;font-style: italic;margin-bottom: 0;">
          <p class="">This site is developed and maintained by:
            <cite title="Source Title" style="text-decoration: underline;">
              <a href="https://indrakumarmhaski.github.io" target="_blank" style="color:#d6d6d6;">
              Er. Indra Kumar Mhaski
              </a>
            </cite>
          </p>
        </blockquote>
      </div>         <!-- ...Inner container of footer -->
    </section>    <!-- ...Footer section -->







  </div>
  <!-- End of main container -->







  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN"
    crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q"
    crossorigin="anonymous"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl"
    crossorigin="anonymous"></script>
</body>

</html>