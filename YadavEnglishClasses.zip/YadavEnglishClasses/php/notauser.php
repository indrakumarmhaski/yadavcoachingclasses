<?php
session_start();
session_destroy();
?>
<!-- If you are not a authorised user then only you will come to this page 
     and you will be thrown to loginpage after three seconds. -->

<!DOCTYPE html>
<html lang="en">
    <head>
        <title></title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <link href="css/notauser.css" rel="stylesheet">
        <script defer src="https://use.fontawesome.com/releases/v5.0.3/js/all.js"></script>
  <script defer src="https://use.fontawesome.com/releases/v5.0.3/js/v4-shims.js"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm"
    crossorigin="anonymous">

        
        <script type="text/javascript">
            function Redirect() {
               window.location="../index.php";
            }
            
            setTimeout('Redirect()', 3000);
      </script>

    </head>
    <body>
            <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
                   <div class="collapse navbar-collapse" id="navbarSupportedContent">
                      <ul class="navbar-nav mr-auto">
                        <li class="nav-item active">
                        <li class="nav-item dropdown">
                        </li>
                      </ul>
                      <h4 style="color:aqua;">Yadav Coaching Classes</h4>
                    </div>
                  </nav>
    <div class="container outer-body">
              <h3 id="heading">UserName and Password Does not exist!</h3>
        <div id="form-container">
             

            


        </div>


    </div>
    
    <footer>
        <blockquote class=" blockquote">
            <p class="mb-0">Please login with right password and username.</p>
            <div style="float: right; margin-right:5px; background-color:gainsboro;" class="blockquote-footer ikm col-sm-12 ">Mr. <cite title="Source Title">Indra Kumar Mhaski</cite></div>
          </blockquote>
    </footer>
        <script src=""></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.3/umd/popper.min.js" integrity="sha384-vFJXuSJphROIrBnz7yo7oB41mKfc8JzQZiCq4NCceLEaO4IHwicKwpJf9c9IpFgh" crossorigin="anonymous"></script>
        <script src="node_modules\bootstrap\dist\js\bootstrap.min.js"></script>
    </body>
</html>