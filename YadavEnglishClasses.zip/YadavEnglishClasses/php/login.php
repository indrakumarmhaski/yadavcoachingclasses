<?php
// Here is the logic to login if username and passord eixst in db then you will be 
// logedin.
session_start();
$username=$_POST['username'];
$password=$_POST['password'];

$con=mysqli_connect('localhost','id5135699_root','Indra@123');
      mysqli_select_db($con,'id5135699_ycc'); 
$q="select * from owner where username='$username' and password='$password'";
$result=mysqli_query($con,$q);
$num=mysqli_num_rows($result);
if($num==1)
{
      // If you are a authorized user then you will be thrown to you accountpage.
      $_SESSION['username']=$username;
      $_SESSION['password']=$password;
      header('location:editclass10.php');
}
else
{
      // If you are not authorized user then you will be thrown to that page
      header('location:notauser.php');
}
mysqli_close($con);
?>