<?php
session_start();
$con=mysqli_connect('localhost','id5135699_root','Indra@123');
      mysqli_select_db($con,'id5135699_ycc'); 
if( !isset($_SESSION['username']) || !isset($_SESSION['password']) )
{
    header('location:../index.php');
}

$_SESSION['tablename']='spoken';
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
 <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Yadav English Classes</title>

  <script defer src="https://use.fontawesome.com/releases/v5.0.3/js/all.js"></script>
  <script defer src="https://use.fontawesome.com/releases/v5.0.3/js/v4-shims.js"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm"
    crossorigin="anonymous">

  <link rel="stylesheet" href="../css/getfeestructure_style.css">
</head>

<body>


  <div class="container-fluid">  <!-- The main container of all the elements in body -->
    <nav class="navbar navbar-expand-lg navbarstyle" >
      <!-- Start of navbar -->
      <div class=" navbar-collapse mo-num ml-lg-4 ml-xs-1 ml-sm-2">
        <a class="mobilenumber" href="">
          <i class="fa fa-phone" style="color:white;"></i>
          <span style="color:white;">
            09752963965
          </span>
        </a>
      </div>
      <div class="quik-links justify-content-end" id="navbarCollapse">
        <ul class="navbar-nav">
          <li class="box-list" class="nav-item dropdown mr-auto">
                <a class="nav-link " href="logout.php" id="navbarDropdown" aria-haspopup="true"
                aria-expanded="false">
                LogOut
              </a>
          </li>
        </ul>
      </div>
    </nav>    <!-- End of the navbar Job completed -->

    <section>      <!-- Section for the heading(yadav coching classes) of site -->
      <div class="siteheading mb-lg-0 mt-4">
        <div class="sitebranding">
          <h2 class="sitetitle">
            <span href="">Yadav Coaching Classes</span>
          </h2>
          <p class="sitedescription">Learn English as it is fun !</p>
        </div>
      </div>
    </section>    <!-- ...Heading -->


    <nav class="navbar navbar-expand-lg navbarstyle" class="secon-nav">
      <!-- Start of navbar -->
      <div class=" navbar-collapse mo-num ml-lg-4 ml-xs-1 ml-sm-2">
        <a class="mobilenumber" href="">
          <span style="color:white;">
          </span>
        </a>
      </div>
      <div class="quik-links justify-content-end" id="navbarCollapse">
        <ul class="navbar-nav">
          <li class="box-list" class="nav-item dropdown mr-auto">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true"
              aria-expanded="false">
               What to edit ?
            </a>
            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
            <a class="dropdown-item" href="editbetchtiming.php">
                Edit Betch Timing
              </a>
              <div class="dropdown-divider"></div>
              <a class="dropdown-item" href="editclass10.php">
                Edit 10th class
              </a>
              <div class="dropdown-divider"></div>
              <a class="dropdown-item" href="editclass11.php">
                Edit 11th class
              </a>
            
            <div class="dropdown-divider"></div>
              <a class="dropdown-item" href="editclass12.php">
                Edit 12th class
              </a>
            </div>
          </li>
        </ul>
      </div>
    </nav>    <!-- End of the navbar Job completed -->


<section class="container mb-3" >
    <h3 class="text-center">Edit spoken class</h3>

    <?php
      $q="select * from spoken";
      $r=mysqli_query($con,$q);
      $arr=mysqli_fetch_array($r); 
    ?>
    <form action="insertdata.php" method="post">
        <h3 class="text-left">Descripton:</h3>
    <textarea name="description" cols="184" class="col-sm-12"  rows="5"><?php echo $arr['description'] ?>
    </textarea>
     
    <article class="intallment-table col-md-5 mt-sm-1 mt-xs-1 table-costome">
                    <h5 class="text-center">Fee Structure</h5>
                  <table class="table">
                      <thead>
                          <th>Installment</th>
                          <th>Fee</th>
                      </thead>
                      <tbody>
                          <tr>
                              <td>1st</td>
                              <td>&#8377; 
                              <input type="text" name="inst1" value="<?php echo $arr['inst1'] ?>" >
                              </td>
                          </tr>
                          <tr>
                                <td>2nd</td>
                                <td>&#8377; 
                                <input type="text" name="inst2" value="<?php echo $arr['inst2'] ?>" >      
                                </td>
                          </tr>
                          <tr>
                                <td>3rd</td>
                                <td>&#8377; 
                                <input type="text" name="inst3" value="<?php echo $arr['inst3'] ?>" >     
                                </td>
                          </tr>
                          <tr>
                                <td>4th</td>
                                <td>&#8377; 
                                <input type="text" name="inst4" value="<?php echo $arr['inst4'] ?>" >    
                                </td>
                          </tr>
                          <tr>
                                <td>Toal</td>
                                <td>&#8377; 
                                <input type="text" name="total" value="<?php echo $arr['total'] ?>" >
                                </td>
                          </tr>
                      </tbody>
                  </table>
      
                </article>

      <input class="btn btn-primary" style="width: 91px;margin-left: 31px;" type="submit" value="Submit">
      <input class="btn btn-danger " style="width: 91px; margin-left:18px;" type="reset" value="Reset">
    </form>
</section>




    <section class="site-footer">      <!-- Footer section of site -->
      <div class="container">
        <div class="row text-center">
          <div class="col-lg-7 mt-4 tex-center">
            <h5 style="color: #fff">OUR MISSION</h5>
            <p style="color:#d6d6d6;font-style: italic;">
              Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy
              text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen
              book.
            </p>
          </div>

          <article class="col-md-5 mt-lg-5 mt-sm-1 mt-xs-1 pt-lg-3 table-costome">
            <dl class="dl-horizontal">
              <dt style="color: #fff">Director: </dt>
              <dd style="color:#d6d6d6;font-style: italic;">Purushottam Yadav</dd>
              <br>
              <dt style="color: #fff">Address: </dt>
              <dd>
                <address style="color:#d6d6d6;font-style: italic;">Krshnapura tikari, Betul, MP, INDIA </address>
              </dd>
            </dl>

          </article>
        </div>
        <!-- horizontal line between ourmission and copiright section -->
        <hr style="color: white; border-top: 1px solid white; margin-top: 0;">
        <div class="text-center" style="font-size:2em;">
            <a style="color: #919394;" href="https://www.facebook.com/purushottam.yadav.16752">
              <i class="icon 3x fab fa-facebook-square"></i>
              </a>
        </div>
        <br>

        <p class="text-center copiright">&copy; Copyright
          <script>document.write(new Date().getFullYear())</script>
          <span style="color: #d6d6d6">Yadav Coaching Classes</span>
        </p>
        <!-- Devloper section -->
        <blockquote class="blockquote pb-3 text-left" style="color:#d6d6d6;font-style: italic;margin-bottom: 0;">
          <p class="">This site is developed and maintained by:
              <cite title="Source Title" style="text-decoration: underline;">
                  <a href="https://indrakumarmhaski.github.io" target="_blank" style="color:#d6d6d6;">
                  Er. Indra Kumar Mhaski
                  </a>
                </cite>
          </p>
        </blockquote>
      </div>         <!-- ...Inner container of footer -->
    </section>    <!-- ...Footer section -->







  </div>
  <!-- End of main container -->







  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN"
    crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q"
    crossorigin="anonymous"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl"
    crossorigin="anonymous"></script>
</body>

</html>