<?php
session_start();
if( !isset($_SESSION['username']) || !isset($_SESSION['password']) )
{
    header('location:../index.php');
}
$tablename=$_SESSION['tablename'];




$con=mysqli_connect('localhost','id5135699_root','Indra@123');
      mysqli_select_db($con,'id5135699_ycc'); 


if($tablename=='class10' || $tablename=='class11' || $tablename=='class12' || $tablename=='spoken' )
 {
    $description=$_POST['description'];
    $inst1=$_POST['inst1'];
    $inst2=$_POST['inst2'];
    $inst3=$_POST['inst3'];
    $inst4=$_POST['inst4'];
    $total=$_POST['total'];
     $q="update $tablename set description='$description', inst1=$inst1, inst2=$inst2,
      inst3=$inst3, inst4=$inst4 , total=$total";
     $res=mysqli_query($con,$q);
 }
 else if($tablename=='betchtiming')
 {
     $b1=$_POST['b1'];
     $b2=$_POST['b2'];
     $b3=$_POST['b3'];
     $b4=$_POST['b4'];
     $b5=$_POST['b5'];
     $t1=$_POST['t1'];
     $t2=$_POST['t2'];
     $t3=$_POST['t3'];
     $t4=$_POST['t4'];
     $t5=$_POST['t5'];
     $l1=$_POST['l1'];
     $l2=$_POST['l2'];
     $l3=$_POST['l3'];
     $l4=$_POST['l4'];
     $l5=$_POST['l5'];
     $q="update betchtiming set 
     b1='$b1' ,
     b2='$b2' ,
     b3='$b3' ,
     b4='$b4' ,
     b5='$b5' ,
     t1='$t1' ,
     t2='$t2' ,
     t3='$t3' ,
     t4='$t4' ,
     t5='$t5' ,
     l1='$l1' ,
     l2='$l2' ,
     l3='$l3' ,
     l4='$l4' ,
     l5='$l5' 
     ";
     $res=mysqli_query($con,$q);
}

 

 if($res==1)
 {
     header("location:edit$tablename.php");
 }
 else
 {
     echo "Some error";
 }



?>