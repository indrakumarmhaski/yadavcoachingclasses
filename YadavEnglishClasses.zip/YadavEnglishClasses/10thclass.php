
    <?php
    
      $con=mysqli_connect('localhost','id5135699_root','Indra@123');
      mysqli_select_db($con,'id5135699_ycc');       
      $q="select * from class10";
      $r=mysqli_query($con,$q);
      $arr=mysqli_fetch_array($r); 
    ?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
 <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Yadav English Classes</title>

  <script defer src="https://use.fontawesome.com/releases/v5.0.3/js/all.js"></script>
  <script defer src="https://use.fontawesome.com/releases/v5.0.3/js/v4-shims.js"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm"
    crossorigin="anonymous">

  <link rel="stylesheet" href="css/commonforclaases_style.css">
</head>

<body>


  <div class="container-fluid">  <!-- The main container of all the elements in body -->
    <nav class="navbar navbar-expand-lg navbarstyle" >
      <!-- Start of navbar -->
      <div class=" navbar-collapse mo-num ml-lg-4 ml-xs-1 ml-sm-2">
        <a class="mobilenumber" href="">
          <i class="fa fa-phone" style="color:white;"></i>
          <span style="color:white;">
            09752963965
          </span>
        </a>
      </div>
      <div class="quik-links justify-content-end" id="navbarCollapse">
        <ul class="navbar-nav">
          <li class="box-list" class="nav-item dropdown mr-auto">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true"
              aria-expanded="false">
              Quick Links
            </a>
            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
              <a class="dropdown-item" href="">
                <i class="fas fa-phone-square"></i>
                09752963965
              </a>
              <div class="dropdown-divider"></div>
              <a class="dropdown-item" href="">
                <i class="fas fa-envelope-square"></i>
                yadavenglishclasses@gmail.com
              </a>
              <div class="dropdown-divider"></div>
              <a class="dropdown-item" href="getfeestructure.html">
                  <i class="far fa-credit-card"></i>
                Fee Structure
              </a>
            </div>
          </li class="box-list">
        </ul>
      </div>
    </nav>    <!-- End of the navbar Job completed -->

    <section>      <!-- Section for the heading(yadav coching classes) of site -->
      <div class="siteheading mt-4">
        <div class="sitebranding">
          <h2 class="sitetitle">
            <span href="">Yadav Coaching Classes</span>
          </h2>
          <p class="sitedescription">Learn English as it is fun !</p>
        </div>
      </div>
    </section>    <!-- ...Heading -->

    <section class=" introduction">  <!--For site introduction section having a background imgae  -->
       <div class="container">
        <h3 class="text-center mt-5" style="font-size: 37px;
        text-decoration: underline;
        font-family: cursive;">10th class batch</h3>

        <div class="row mt-4 info-row text-center">
                <div class="col-lg-7 tex-center">
                  <h5>Description</h5>
                  <p style="font-style: italic;">
                
                                <?php echo $arr['description'] ?> 
                     
                  </p>
                  <a href="index.php">
                        <button type="button" class="btn btn-primary">Home Page</button>
                  </a>
                </div>
      
                <article class="intallment-table col-md-5 mt-sm-1 mt-xs-1 table-costome">
                    <h5>Fee Structure</h5>
                  <table class="table">
                      <thead>
                          <th>Installment</th>
                          <th>Fee</th>
                      </thead>
                      <tbody>
                          <tr>
                              <td>1st</td>
                              <td>&#8377; 
                              <?php echo $arr['inst1'] ?>  
                              </td>
                          </tr>
                          <tr>
                                <td>2nd</td>
                                <td>&#8377; 
                                <?php echo $arr['inst2'] ?> 
                                </td>
                          </tr>
                          <tr>
                                <td>3rd</td>
                                <td>&#8377; 
                                <?php echo $arr['inst3'] ?> 
                                </td>
                          </tr>
                          <tr>
                                <td>4th</td>
                                <td>&#8377; 
                                <?php echo $arr['inst4'] ?> 
                                </td>
                            </tr>
                            <tr>
                                <td>Total</td>
                                <td>&#8377; 
                                <?php echo $arr['total'] ?> 
                                </td>
                            </tr>
                      </tbody>
                  </table>
      
                </article>
        </div>




       </div>
    </section><!-- ...site introduction  -->


    <hr>


 


   

    <br>

    <!-- Heading how to contect us -->
    <h2 class="text-center pb-lg-4 pb-sm-2 pb-xs-2">
      <i class="far fa-address-card"></i>
      How to contect us?</h2>      <!-- ...Heading how to contect us  -->
 
 


   <section class="row contect-us">     <!-- How to contect us main contect -->
      <div class="col-md-6 col-sm-12 col-sx-12">
        <p class="text-center text-lead mt-lg-3 mt-sm-0 mt-xs-0">
          <!-- how to contect us description -->
          Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy
          text ever since the 1500s when an unknown printer took a galley of type and scrambled it to make a type specimen
          book.
        </p>
      </div>
      <article class="col-md-6 table-costome">
        <dl class="dl-horizontal">
          <dt>Email:</dt>
          <dd>yadavenglishclasses@gmail.com</dd>
          <br>
          <dt>Address</dt>
          <dd>
            <address>Krshnapura tikari, Betul, MP, INDIA </address>
          </dd>
          <br>
          <dt>Mobile</dt>
          <dd>+91 97529 63965</dd>
        </dl>
      </article>
    </section>    <!-- ...How to contect us -->

      <br>
       <hr>

    <div class="gallery-section-container">      <!-- Main container of gallery section -->
      <section class="container gallery ">      <!-- Section gallery section -->
        <h2 class="text-center pt-3 mb-lg-5 mb-s" style="color: white; ">
          <i class="fas fa-images"></i>
          Gallery</h2>
        <div class="img-container img-fluid">

          <div id="demo" class="carousel slide" data-ride="carousel">
            <ul class="carousel-indicators">
              <li data-target="#demo" data-slide-to="0" class="active"></li>
              <li data-target="#demo" data-slide-to="1"></li>
              <li data-target="#demo" data-slide-to="2"></li>
              <li data-target="#demo" data-slide-to="3"></li>
              <li data-target="#demo" data-slide-to="4"></li>
              <li data-target="#demo" data-slide-to="5"></li>
            </ul>
            <div class="carousel-inner">
              <div class="carousel-item active">
                <img src="images/img_slide1.jpg" class="img-fluid gallery-img" alt="Los Angeles">
              </div>
              <div class="carousel-item">
                <img src="images/img_slide5.jpg" class="img-fluid gallery-img" alt="Chicago">
              </div>
              <div class="carousel-item">
                <img src="images/img_slide3.jpg" class="img-fluid gallery-img" alt="New York">
              </div>
              <div class="carousel-item">
                <img src="images/img_slide4.jpg" class="img-fluid gallery-img" alt="New York">
              </div>
              <div class="carousel-item">
                <img src="images/img_slide2.jpg" class="img-fluid gallery-img" alt="New York">
              </div>
            </div>

            <a class="carousel-control-prev" href="#demo" data-slide="prev">
              <span class="carousel-control-prev-icon" style="background-color: black;"></span>
            </a>
            <a class="carousel-control-next" href="#demo" data-slide="next">
              <span class="carousel-control-next-icon" style="background-color: black;"></span>
            </a>
          </div>
        </div>
        <!-- End of img container -->
      </section>      <!-- ...Gallery section -->
    </div>    <!-- whole Gallery container -->


    <section class="site-footer">      <!-- Footer section of site -->
      <div class="container">
        <div class="row text-center">
          <div class="col-lg-7 mt-4 tex-center">
            <h5 style="color: #fff">OUR MISSION</h5>
            <p style="color:#d6d6d6;font-style: italic;">
              Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy
              text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen
              book.
            </p>
          </div>

          <article class="col-md-5 mt-lg-5 mt-sm-1 mt-xs-1 pt-lg-3 table-costome">
            <dl class="dl-horizontal">
              <dt style="color: #fff">Director: </dt>
              <dd style="color:#d6d6d6;font-style: italic;">Purushottam Yadav</dd>
              <br>
              <dt style="color: #fff">Address: </dt>
              <dd>
                <address style="color:#d6d6d6;font-style: italic;">Krshnapura tikari, Betul, MP, INDIA </address>
              </dd>
            </dl>

          </article>
        </div>
        <!-- horizontal line between ourmission and copiright section -->
        <hr style="color: white; border-top: 1px solid white; margin-top: 0;">
        <div class="text-center" style="font-size:2em;">
            <a style="color: #919394;" href="https://www.facebook.com/purushottam.yadav.16752">
              <i class="icon 3x fab fa-facebook-square"></i>
              </a>
        </div>
        <br>

        <p class="text-center copiright">&copy; Copyright
          <script>document.write(new Date().getFullYear())</script>
          <span style="color: #d6d6d6">Yadav Coaching Classes</span>
        </p>
        <!-- Devloper section -->
        <blockquote class="blockquote pb-3 text-left" style="color:#d6d6d6;font-style: italic;margin-bottom: 0;">
          <p class="">This site is developed and maintained by:
              <cite title="Source Title" style="text-decoration: underline;">
                  <a href="https://indrakumarmhaski.github.io" target="_blank" style="color:#d6d6d6;">
                  Er. Indra Kumar Mhaski
                  </a>
                </cite>
          </p>
        </blockquote>
      </div>         <!-- ...Inner container of footer -->
    </section>    <!-- ...Footer section -->







  </div>
  <!-- End of main container -->







  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN"
    crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q"
    crossorigin="anonymous"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl"
    crossorigin="anonymous"></script>
</body>

</html>